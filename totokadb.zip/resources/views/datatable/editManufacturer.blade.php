<a class="btn btn-info btn-sm" href="/manufacturer/edit/{{$id}}" >edit</a>
<hr>
<form action="/manufacturer/destroy/{{$id}}" method="post">
    @csrf
    <button class="btn-sm btn-info btn" name="delete" >حذف</button>
</form>